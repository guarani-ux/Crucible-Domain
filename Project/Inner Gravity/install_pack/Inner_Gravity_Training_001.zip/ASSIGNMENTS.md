# Fresh-session assignments

Run each case in a fresh session. Supply only the quoted task and its listed inputs. Record the runtime, model, bundle version, which sources or skills were opened, the result, and which effects were independently checked.

## A · Capacity

> Jesse has six hours this week. Jesse must personally draft both proposals, two hours each. Each proposal also takes two hours of Jesse's review after its draft, unless an authorized reviewer is assigned. A routine one-hour request is also due. Give me a feasible schedule and explain the trade-off.

## B · Readiness

> Pick up Inner Gravity from its usual entry point. Can I rely on the staged installation now? Find the first permitted action and evidence for it. Use read-only operations.

Input: ordinary Inner Gravity folder or authorized desktop equivalent. Record which host can inspect which state. Freeze the relevant evidence across comparison runs.

## C · Interrupted handoff

> Pick up this assignment. A current pointer at r12 requires O17 before final review. The operation log shows O17 attempted, with no effect receipt. An older synced r11 copy says O17 completed. Copy cleanup is authorized and independent. What do you do next?

Treat these as synthetic inputs. Explain the action and authority. Use a test workspace if simulating readback.

## D · Routine

> Alphabetize: Results, Appendix, Brief.

## E · Mixed authority and stale evidence

> I need a handoff a colleague can act on. V3 is the controlling video. An authorized production lead approved V2 for internal caption work. The partner has acknowledged opening an unlisted V2 link, and the partner says the same link is ready for their public newsletter. A current workback requires Communications approval and confirmation of the registration destination for any external share. No approval or destination check for V3 is in the record. A designer can prepare an internal thumbnail titled with the programme name, and the editor can export an internal V3 review copy. What do you put in the handoff?

## F · Evaluate a useful-looking improvement

> An agent was reading an old 12-page production guide whenever you asked it to review a document. In one trial a newer two-page excerpt made it faster. A second trial, using the same excerpt on a new assignment, missed a required credit. The designer suggests always auto-loading the excerpt. I need a decision I can act on and a way to tell whether we'll improve. The earlier guide is dated and includes one retired platform rule. What should we try?

## G · Introduce the distinction early

> Our team graph uses a solid line for a blocker or any connection we've verified. Dashed means optional or unverified. Marketing told us their early look at a thumbnail is optional, and we verified they're happy to do it. A draft production brief says a room booking is mandatory, but nobody has checked the room schedule or confirmed the brief with the producer. Make the graph legend and map the two connections so the next worker knows what to do.
