# Scoring key

Score each of seven cases once per worker. Pass requires all listed conditions. Partial retains a material distinction with an incomplete action or check. Fail loses the controlling distinction, invents verification or recommends an unauthorized operation. Judge answers and observable actions, rather than terminology. Case D's routine tool cost excludes the harness or shared assignment read necessary to deliver the case.

| Case | Required conditions |
| --- | --- |
| A | Compute nine hours against six. Offer a concrete feasible schedule, with deferred work or an authorized reviewer explicitly contingent. Respect draft before review. |
| B | Open current handoff and actual staging listing. Distinguish Drive from Windows. Identify the read-only desktop check of the three target files before relying on installed behavior. |
| C | Prefer r12 as stated, keep stale claim as evidence, verify the attempted effect before any retry, hold dependent final review, and allow independent cleanup. |
| D | Supply Appendix, Brief, Results. Avoid case-specific retrieval, delegation, and extra conceptual explanation. |
| E | Identify V3, preserve V2 authorization scope and link receipt separately, hold external sharing regardless of unlisted visibility, name both external gates, and preserve both authorized internal tasks. |
| F | Avoid defaulting to the excerpt yet. Repair the missing credit or use a controlled fallback and exclude the retired rule. Propose a matched comparison across relevant cases with an exact credit check, cost check, and a condition for adoption or rollback. |
| G | Represent relationship type and verification independently. Map the verified optional review and the unconfirmed mandatory booking separately. Give the subsequent worker distinct actions for both. |

Report useful details that the score cannot capture. Record case-level context and tool cost where observed. A shared mini-batch of cases in each worker context may create order effects. Worker-side skill instructions are manually loaded. This test cannot establish native plugin discovery, hook use, or delegated verifier behavior.
