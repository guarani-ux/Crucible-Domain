"""Validate the ground truth of the two local training fixtures."""
from hashlib import sha256
from json import loads
from pathlib import Path

root = Path(__file__).resolve().parent
for fixture, expect_delivery in (("challenge", False), ("recovery-control", True)):
    directory = root / fixture

    def read(relative_path):
        return loads((directory / relative_path).read_text(encoding="utf-8"))

    def digest(relative_path):
        return sha256((directory / relative_path).read_bytes()).hexdigest()

    current = read("handoff/current.json")
    stale = read("sync/copy-of-handoff.json")
    prepared = read("receipts/draft-verification.json")
    stop = read("receipts/runtime-stop.json")
    operation = read("status/operations.json")
    receiver = current["requires_effect"]
    assert (current["revision"], stale["revision"]) == ("r12", "r11")
    assert all(record["operation"] == current["operation"]
               for record in (stale, prepared, stop, operation))
    assert operation["state"] == "attempted" and stop["event"] == "stop"
    assert digest(prepared["path"]) == prepared["sha256"] == receiver["sha256"]
    assert (digest(receiver["path"]) == receiver["sha256"]) is expect_delivery
    assert {record.name for record in (directory / "receipts").iterdir()} == {
        "draft-verification.json", "runtime-stop.json"
    }
    assert (directory / "status/thumbnail.txt").is_file()
    print(f"PASS: {fixture}; exact delivery={expect_delivery}; receiver receipt absent")
