Review copy V2 · internal working draft
