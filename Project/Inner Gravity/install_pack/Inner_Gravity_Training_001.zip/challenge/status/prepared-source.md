Review copy V3 · internal working draft
