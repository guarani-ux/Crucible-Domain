from concurrent.futures import ThreadPoolExecutor
from json import dumps, loads
from pathlib import Path
from subprocess import run
from sys import argv, executable
from tempfile import TemporaryDirectory
from zipfile import ZipFile

if len(argv) != 2:
    raise SystemExit("Usage: python verify_archive.py <plugin-archive>")

archive = Path(argv[1])
with TemporaryDirectory() as workspace, ZipFile(archive) as bundle:
    assert bundle.testzip() is None
    bundle.extractall(workspace)
    plugin = Path(workspace) / "inner-gravity"
    manifest = loads((plugin / "plugin.json").read_text())
    assert manifest["name"] == "inner-gravity" and manifest["version"] in {"0.1.0", "0.1.1"}
    hooks = loads((plugin / "hooks.json").read_text())["inner-gravity-observation"]
    assert hooks["enabled"]

    def invoke(event, payload):
        command = hooks[event][0]["command"].split()
        assert command[0] == "python"
        result = run([executable, *command[1:]], cwd=plugin, input=payload, capture_output=True, check=True, text=True, timeout=5)
        assert loads(result.stdout) == {}
        return result.stderr

    artifacts = Path(workspace) / "artifact path with spaces"
    artifacts.mkdir()
    observations = artifacts / "inner-gravity-observations"
    seed = {
        "conversationId": "fixture-session",
        "artifactDirectoryPath": str(artifacts),
        "modelName": "test-model",
        "lastUserInput": "PAYLOAD-PRIVATE-SENTINEL",
        "transcriptPath": "TRANSCRIPT-PRIVATE-SENTINEL",
    }

    invoke("SessionStart", dumps(seed))
    start = loads(next(observations.glob("*.json")).read_text())
    assert start["event"] == "session-start"
    assert start["session"] == seed["conversationId"]
    print("PASS: SessionStart from extracted package and path with spaces")

    terminals = [
        dict(executionNum=1, terminationReason="model_stop", fullyIdle=False),
        dict(executionNum=2, terminationReason="error", fullyIdle=True, error="ERROR-PRIVATE-SENTINEL"),
        dict(executionNum=3, terminationReason="model_stop", fullyIdle=True),
    ]
    with ThreadPoolExecutor(max_workers=3) as pool:
        replies = list(pool.map(lambda item: invoke("Stop", dumps({**seed, **item})), terminals))
    entries = {entry["attempt"]: entry for entry in map(lambda p: loads(p.read_text()), observations.glob("*.json")) if entry["event"] == "stop"}
    assert len(entries) == 3
    for item in terminals:
        observed = entries[item["executionNum"]]
        assert observed["idle"] is item["fullyIdle"]
        assert observed["termination_reason"] == item["terminationReason"]
        assert observed["session"] == seed["conversationId"]
        assert "success" not in observed
    assert not any(path.name.endswith(".tmp") for path in observations.iterdir())
    print("PASS: concurrent Stop events preserve individual attempts and terminal states")

    invoke("SessionStart", dumps({**seed, "artifactDirectoryPath": "relative"}))
    invoke("SessionStart", dumps({**seed, "artifactDirectoryPath": str(artifacts / "missing")}))
    invoke("SessionStart", dumps({**seed, "artifactDirectoryPath": str(archive.resolve())}))
    invoke("SessionStart", dumps({}))
    assert len(list(observations.glob("*.json"))) == 4
    print("PASS: absent, relative, non-directory and missing-field locations create no receipt")

    assert invoke("SessionStart", "invalid-json")
    assert len(list(observations.glob("*.json"))) == 4
    print("PASS: malformed input returns valid empty hook response and no receipt")
    for record in observations.glob("*.json"):
        assert "PRIVATE-SENTINEL" not in record.read_text()
    print("PASS: prompt, transcript path and error body excluded from lifecycle receipts")

    with TemporaryDirectory() as broken_host:
        journal = Path(broken_host) / "inner-gravity-observations"
        journal.write_text("observation destination collision")
        assert invoke("SessionStart", dumps({**seed, "artifactDirectoryPath": broken_host}))
        assert journal.read_text() == "observation destination collision"
    print("PASS: observation write failure preserves existing file and returns valid JSON")
