# Inner Gravity qualification fixtures

This pack contains the seven worker assignments, the separate scoring key, two synthetic recovery workspaces, and two standard-library test scripts. Run the scripts from the extracted pack with Python 3.8 or newer:

    python verify_archive.py path/to/Inner_Gravity_Antigravity_Plugin_0.1.1.zip
    python check_handoff_fixtures.py

The first extracts the actual archive into temporary storage and runs its configured observation script with fixture events. The second verifies the ground truth of both recovery workspaces. The stale workspace has a prepared V3 source and V2 at the destination. The recovered workspace has V3 at the destination. Both lack a recipient acknowledgment. Preserve the fixture inputs when comparing runs.

For fresh-worker evaluation, give each worker only the assignment and its fixture or allowed live sources. Give the separate scoring key to the reviewer. Record whether instructions were loaded as text or discovered in the native Antigravity host.
